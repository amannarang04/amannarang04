import json
import os
import urllib.request
from datetime import datetime, timezone
from html import escape

USERNAME = os.getenv("GITHUB_USERNAME", "amannarang04")
TOKEN = os.getenv("GITHUB_TOKEN")

headers = {
    "Accept": "application/vnd.github+json",
    "User-Agent": "aman-github-command-center",
}
if TOKEN:
    headers["Authorization"] = f"Bearer {TOKEN}"

def api(path):
    req = urllib.request.Request(
        f"https://api.github.com{path}",
        headers=headers
    )
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.load(r)

repos = api(f"/users/{USERNAME}/repos?per_page=100&sort=updated")
repos = [r for r in repos if not r.get("fork") and not r.get("archived")]
repos.sort(key=lambda r: (r.get("stargazers_count", 0), r.get("updated_at", "")), reverse=True)
top = repos[:6]

lang_colors = {
    "Python": "#3776AB", "JavaScript": "#F7DF1E", "TypeScript": "#3178C6",
    "Java": "#ED8B00", "HTML": "#E34F26", "CSS": "#1572B6",
    "C++": "#00599C", "C": "#A8B9CC", "Jupyter Notebook": "#F37626"
}

def card(repo, x, y):
    name = escape(repo["name"][:22])
    desc = escape((repo.get("description") or "No description")[:46])
    lang = repo.get("language") or "Code"
    dot = lang_colors.get(lang, "#22D3EE")
    stars = repo.get("stargazers_count", 0)
    return f'''
    <g transform="translate({x},{y})">
      <rect width="285" height="118" rx="12" fill="#0b1220" stroke="#233247"/>
      <rect width="4" height="118" rx="2" fill="{dot}"/>
      <text x="18" y="30" class="title">{name}</text>
      <text x="18" y="53" class="desc">{desc}</text>
      <circle cx="20" cy="86" r="5" fill="{dot}"/>
      <text x="32" y="90" class="meta">{escape(lang)}</text>
      <text x="210" y="90" class="meta">★ {stars}</text>
    </g>'''

cards = ""
positions = [(40,300),(335,300),(630,300),(40,432),(335,432),(630,432)]
for repo, pos in zip(top, positions):
    cards += card(repo, *pos)

now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="960" height="590" viewBox="0 0 960 590">
<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#050816"/><stop offset="1" stop-color="#0b1020"/></linearGradient>
<filter id="glow"><feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
<style>
.title{{fill:#f8fafc;font:600 17px monospace}}
.desc{{fill:#94a3b8;font:13px monospace}}
.meta{{fill:#64748b;font:12px monospace}}
.label{{fill:#22d3ee;font:12px monospace;letter-spacing:2px}}
.hero{{fill:#f8fafc;font:700 38px monospace;letter-spacing:3px}}
.sub{{fill:#94a3b8;font:14px monospace}}
.cursor{{animation:blink 1s steps(2,start) infinite}}
.pulse{{animation:pulse 2s ease-in-out infinite}}
@keyframes blink{{50%{{opacity:0}}}}
@keyframes pulse{{50%{{opacity:.35}}}}
</style></defs>
<rect width="960" height="590" rx="18" fill="url(#bg)"/>
<rect x="1" y="1" width="958" height="588" rx="18" fill="none" stroke="#1e293b"/>
<g opacity=".16" stroke="#334155"><path d="M0 110H960M0 210H960M0 290H960M0 560H960"/><path d="M160 0V590M320 0V590M640 0V590M800 0V590"/></g>
<circle cx="830" cy="92" r="90" fill="#22d3ee" opacity=".07" class="pulse"/>
<text x="40" y="45" class="label">AMAN // GITHUB COMMAND CENTER</text>
<circle cx="890" cy="39" r="6" fill="#22c55e" filter="url(#glow)"/>
<text x="905" y="44" class="meta">ONLINE</text>
<text x="40" y="95" class="hero">AMAN NARANG</text>
<text x="42" y="123" class="sub">AI / ML  •  FULL STACK  •  PRODUCT BUILDER</text>
<rect x="40" y="150" width="880" height="105" rx="12" fill="#070d19" stroke="#1e293b"/>
<text x="62" y="178" class="label">SYSTEM LOG</text>
<text x="62" y="204" class="sub">aman@github:~$ currently_building</text>
<text x="62" y="229" class="sub">&gt; AI systems  •  products  •  experiments</text>
<text x="62" y="251" class="sub">&gt; repositories loaded: {len(repos)} <tspan class="cursor">█</tspan></text>
<text x="40" y="282" class="label">LIVE PROJECT MATRIX</text>
{cards}
<text x="40" y="570" class="meta">AUTO-UPDATED • {now} • github.com/{USERNAME}</text>
</svg>'''

with open("assets/command-center.svg", "w", encoding="utf-8") as f:
    f.write(svg)
